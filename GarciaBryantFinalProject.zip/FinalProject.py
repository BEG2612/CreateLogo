""" Author: Bryant Garcia
    Date Written: 10/12/24
    Assignment: Final Project
    The Logo Creator App is a simple tool designed for users to create custom logos quickly and efficiently. With a user-friendly interface, 
    the program allows users to design logos by drawing various shapes, adding custom text, and choosing from a range of colors. The app offers 
    features such as moveable objects, shape selection, and the ability to save the final design as a PNG file. With a simple interface, 
    this app is perfect for anyone looking to create easy, but unique logos without needing some form of complex design software."""

import tkinter as tk
from tkinter import colorchooser, simpledialog, messagebox, filedialog
import math
# Secondary Window
class LogoCreator:
    def __init__(self, master, main_app):
        self.master = master
        self.main_app = main_app  # Reference to main app
        master.title("Logo Creator Editor")

        # Make this window modal
        self.master.transient(main_app.root)  # Make the secondary window always on top of the main window
        self.master.grab_set()

        # Grab focus to this window so main window is inaccessible
        self.master.grab_set()

        # Add a label on top
        self.label = tk.Label(master, text="Design your Own Logo", font=("Arial", 14, "bold"), fg="forest green")
        self.label.pack(pady=10)

        # Create canvas
        self.canvas = tk.Canvas(master, width=400, height=300, bg="white")
        self.canvas.pack()

        # Frame for buttons (left and right)
        button_frame = tk.Frame(master)
        button_frame.pack(pady=10)

        # Left column
        left_frame = tk.Frame(button_frame)
        left_frame.grid(row=0, column=0, padx=10)

        # Right column
        right_frame = tk.Frame(button_frame)
        right_frame.grid(row=0, column=1, padx=10)

        # Shape selection
        self.shape_options = ["Rectangle", "Oval", "Line", "Diamond", "Star"]
        self.shape_var = tk.StringVar(value=self.shape_options[0])  # Default shape

        # Dropdown menu for shape selection
        self.shape_menu = tk.OptionMenu(left_frame, self.shape_var, *self.shape_options)
        self.shape_menu.config(width=18, height=2, fg="blue")  # Set width to match buttons
        self.shape_menu.pack(pady=3)

        # Buttons on the left side
        self.color_button = tk.Button(left_frame, text="Choose Color", command=self.choose_color, width=20, height=2, fg="blue")
        self.color_button.pack(pady=5)

        self.text_button = tk.Button(left_frame, text="Add Text", command=self.add_text, width=20, height=2, fg="blue")
        self.text_button.pack(pady=5)

        # Buttons on the right side
        self.toggle_button = tk.Button(right_frame, text="Switch to Move Mode", command=self.toggle_mode, width=20, height=2, fg="blue")
        self.toggle_button.pack(pady=5)

        self.save_button = tk.Button(right_frame, text="Save Logo", command=self.save_logo, width=20, height=2, fg="blue")
        self.save_button.pack(pady=5)

        self.clear_button = tk.Button(right_frame, text="Clear", command=self.clear_canvas, width=20, height=2, fg="blue")
        self.clear_button.pack(pady=5)

        # Add the "Exit" button beneath both columns
        self.main_button = tk.Button(master, text="Exit", command=self.go_back_to_main, width=20, height=2, fg="red")
        self.main_button.pack(pady=10)

        self.color = "black"
        self.is_moving_mode = False

        # Variables for dragging
        self.start_x = None
        self.start_y = None
        self.current_shape = None
        self.current_text = None

        # Bind mouse events
        self.canvas.bind("<Button-1>", self.start_draw)
        self.canvas.bind("<B1-Motion>", self.draw_shape)
        self.canvas.bind("<ButtonRelease-1>", self.release_draw)
        self.canvas.bind("<Button-3>", self.select_shape)

    def go_back_to_main(self):
        # Release grab and close the second window
        self.master.grab_release()
        self.master.destroy()  # Closes the second window

    def choose_color(self):
        color_code = colorchooser.askcolor(title="Choose Color")
        if color_code[1]:
            self.color = color_code[1]
    # Enables to switch between adding and moving shapes
    def toggle_mode(self):
        self.is_moving_mode = not self.is_moving_mode
        if self.is_moving_mode:
            self.toggle_button.config(text="Switch to Add Mode")
            self.canvas.bind("<Button-1>", self.select_shape)
            self.canvas.bind("<B1-Motion>", self.move_shape)
        else:
            self.toggle_button.config(text="Switch to Move Mode")
            self.canvas.bind("<Button-1>", self.start_draw)
            self.canvas.bind("<B1-Motion>", self.draw_shape)

    def start_draw(self, event):
        self.start_x = event.x
        self.start_y = event.y
        self.current_shape = None  # Reset current shape

    def draw_shape(self, event):
        if self.current_shape:
            self.canvas.delete(self.current_shape)  # Remove previous shape
        x1, y1 = self.start_x, self.start_y
        x2, y2 = event.x, event.y
        shape_type = self.shape_var.get()
        # Choosing different shapes
        if shape_type == "Rectangle":
            self.current_shape = self.canvas.create_rectangle(x1, y1, x2, y2, outline=self.color)
        elif shape_type == "Oval":
            self.current_shape = self.canvas.create_oval(x1, y1, x2, y2, outline=self.color)
        elif shape_type == "Line":
            self.current_shape = self.canvas.create_line(self.start_x, self.start_y, event.x, event.y, fill=self.color, width=2)
        elif shape_type == "Diamond":
            self.current_shape = self.create_diamond(x1, y1, x2, y2)
        elif shape_type == "Star":
            self.current_shape = self.create_star(x1, y1, x2, y2)

    def release_draw(self, event):
        if self.current_shape:
            self.canvas.itemconfig(self.current_shape, fill=self.color)
    # Allows to input text on canvas
    def add_text(self):
        text = simpledialog.askstring("Input", "Enter your text here: ", parent=self.master)
        if text:
            x = self.canvas.winfo_width() // 2
            y = self.canvas.winfo_height() // 2
            self.current_text = self.canvas.create_text(x, y, text=text, fill=self.color, font=("Courier", 16))
        # Make sure the secondary window remains active and keeps focus
        self.master.grab_set()  # Re-apply the grab after adding text

    def create_diamond(self, x1, y1, x2, y2):
        return self.canvas.create_polygon(
            (x1 + x2) / 2, y1,  # Top
            x2, (y1 + y2) / 2,  # Right
            (x1 + x2) / 2, y2,  # Bottom
            x1, (y1 + y2) / 2,  # Left
            outline=self.color, fill=self.color
        )

    def create_star(self, x1, y1, x2, y2):
        center_x = (x1 + x2) / 2
        center_y = (y1 + y2) / 2
        size = min(abs(x2 - x1), abs(y2 - y1)) / 2

        points = []
        for i in range(5):
            angle = math.radians(i * 144)  # Star angles
            x = center_x + size * math.cos(angle)
            y = center_y - size * math.sin(angle)
            points.extend((x, y))

        return self.canvas.create_polygon(points, outline=self.color, fill=self.color)

    def select_shape(self, event):
        if self.is_moving_mode:
            item = self.canvas.find_closest(event.x, event.y)
            if item:
                self.canvas.itemconfig(item, fill="yellow")  # Highlight the selected shape
                self.canvas.bind("<B1-Motion>", lambda e, i=item: self.move_shape(e, i))

    def move_shape(self, event, item):
        dx = event.x - self.canvas.coords(item)[0]
        dy = event.y - self.canvas.coords(item)[1]
        self.canvas.move(item, dx, dy)
    # Asks to save logo
    def save_logo(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".bmp",
                                                   filetypes=[("Bitmap files", "*.bmp"),
                                                              ("All files", "*.*")])
        if file_path:
            self.canvas.update()  # Update the canvas
            # Create a bitmap image
            self.canvas.postscript(file=file_path + ".eps")  # Save as EPS
            messagebox.showinfo("Success", "Logo has been saved successfully!")

    def clear_canvas(self):
        self.canvas.delete("all")

    def go_back_to_main(self):
        # This method closes the second window
        self.master.destroy()  # Closes the second window

# Main application class
class MainApp:
    def __init__(self, root):
        self.root = root
        root.title("Logo Creator Main Menu")

        # Set black background color for the main window
        root.configure(bg="black")

        # Labels with white text
        self.label1 = tk.Label(root, text="Welcome to Logo Creator", font=("Courier", 14, "bold"), fg="white", bg="black")
        self.label1.pack(pady=10)

        self.label2 = tk.Label(root, text="Press the button below to begin", font=("Courier", 12, "bold"), fg="white", bg="black")
        self.label2.pack(pady=10)

        # Load images using tkinter PhotoImage and resize them using subsample
        self.img1 = tk.PhotoImage(file="soccer.png").subsample(3, 3)  # Reduce the image size by 3x
        self.img2 = tk.PhotoImage(file="polo.png").subsample(2, 2)  # Reduce the image size by 2x

        # Frame for images and buttons
        self.frame = tk.Frame(root, bg="black")
        self.frame.pack(pady=10)

        # Left image
        self.left_image_label = tk.Label(self.frame, image=self.img1, bg="black")
        self.left_image_label.grid(row=0, column=0, padx=10)

        # Buttons with orange background and navy blue font
        self.button_frame = tk.Frame(self.frame, bg="black")
        self.button_frame.grid(row=0, column=1, padx=10)

        self.button1 = tk.Button(self.button_frame, text="Open Logo Creator", command=self.open_logo_creator, width=20, height=2,
                                 font=("Arial", 12), bg="#ff8c00", fg="blue", relief="raised")
        self.button1.pack(pady=5)

        self.close_button = tk.Button(self.button_frame, text="Close Program", command=self.close_program, width=20, height=2,
                                      font=("Arial", 12), bg="#ff8c00", fg="blue", relief="raised")
        self.close_button.pack(pady=5)

        # Right image
        self.right_image_label = tk.Label(self.frame, image=self.img2, bg="black")
        self.right_image_label.grid(row=0, column=2, padx=10)

    def open_logo_creator(self):
        logo_window = tk.Toplevel(self.root)
        LogoCreator(logo_window, self)

    def close_program(self):
        # Method to close the entire application
        self.root.quit()

if __name__ == "__main__":
    root = tk.Tk()
    app = MainApp(root)
    root.mainloop()